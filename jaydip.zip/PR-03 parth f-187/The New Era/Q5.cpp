#include <iostream>
using namespace std;

class parth
{
private:
    int a, b;

public:
    void getdata(int p, int q)
    {
        this->a = p;
        this->b = q;
    }
    void putdata();
};
void parth ::putdata()
{
    cout << "Add is : " << a + b << endl;
}

int main()
{
    parth p1;
    p1.getdata(10, 20);
    p1.putdata();
}
