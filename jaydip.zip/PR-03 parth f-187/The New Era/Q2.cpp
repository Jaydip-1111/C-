#include <iostream>
using namespace std;
class parth
{
public:
    int h1, h2, s1, s2, m1, m2;
    int sum_t, sum_s, sum_m;

    void getdata()
    {
        cout << "Enter Hour-1 : ";
        cin >> h1;
        cout << "Enter Minite-1 : ";
        cin >> m1;
        cout << "Enter Second-1 : ";
        cin >> s1;

        cout << "Enter Hour-2 : ";
        cin >> h2;
        cout << "Enter Minite-2 : ";
        cin >> m2;
        cout << "Enter Second-2 : ";
        cin >> s2;
    }
    void putdata();
};

void parth::putdata()
{
    sum_t = h1 + h2;
    sum_m = m1 + m2;
    sum_s = s1 + s2;

    while (sum_s >= 3600)
    {
        sum_s = sum_s - 3600;
        sum_t++;
    }
    while (sum_s>= 60)
        {
            sum_s = sum_s - 60;
            sum_m++;
        }
    while (sum_m>= 60)
        {
            sum_m = sum_m - 60;
            sum_t++;
        }

    cout << "Hour is : " << sum_t << endl;
    cout << "Miniutes is : " << sum_m << endl;
    cout << "Second is : " << sum_s << endl;
}

int main()
{
    parth p1;
    p1.getdata();
    p1.putdata();
}