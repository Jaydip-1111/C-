#include <iostream>
using namespace std;
#include <string.h>

class parth
{
public:
    char house_name[100];
    int rooms;
    int floor;
    int rate;
};

int main()
{
    parth e1;

    cout << "Enter House Name - ";
    // fflush(stdin);
    cin >> e1.house_name;

    cout << "Enter Floor - ";
    // fflush(stdin);
    cin >> e1.floor;

    cout << "Enter Rooms - ";
    cin >> e1.rooms;

    cout << "Enter Rate - ";
    // fflush(stdin);
    cin >> e1.rate;
    

    cout <<endl<< "|---------* Final Details *-------------|" << endl;

    cout <<endl<< "House Name - " << e1.house_name << endl;
    cout << "floor No - " << e1.floor << endl;
    cout << "Total Room - " << e1.rooms << endl;
    cout << "Final Rate - " << e1.rate << endl;
    
}