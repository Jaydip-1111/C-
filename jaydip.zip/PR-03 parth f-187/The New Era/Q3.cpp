#include <iostream>
using namespace std;

class time
{
public:
    int sec, hour = 0, min = 0;
    void getdata()
    {
        cin >> sec;
    }
    void putdata()
    {
        while (sec >= 3600)
        {
            sec = sec - 3600;
            hour++;
        }
        while (sec >= 60)
        {
            sec = sec - 60;
            min++;
        }

        cout << "The Time is : " << hour << ":" << min << ":" << sec;
    }
};

int main()
{
    time t1;

    cout << "Enter Time in Seconds : ";
    t1.getdata();
    t1.putdata();

}