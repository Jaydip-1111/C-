#include <iostream>
using namespace std;
class parth
{
public:
    int f1, f2;
    float i1, i2;
    int sum_f1, sum_i1;

    void getdata()
    {
        cout << "Enter feet-1 : ";
        cin >> f1;
        cout << "Enter inch-1 : ";
        cin >> i1;
        cout << "Enter feet-2 : ";
        cin >> f2;
        cout << "Enter inch-2 : ";
        cin >> i2;
    }
    void putdata();
};

void parth::putdata()
{
    sum_f1 = f1 + f2;
    sum_i1 = i1 + i2;

    while (sum_i1 >= 12)
    {
        sum_i1 = sum_i1 - 12;
        sum_f1++;
    }

    cout << "Feet is : " << sum_f1 << endl;
    cout << "Inch is : " << sum_i1 << endl;
}

int main()
{
    parth p1;
    p1.getdata();
    p1.putdata();
}