#include<iostream>
#include<stdio.h>
using namespace std;
int main(){
              int i,size,arr[50];
              cout<<"Enter the size of array:-";
              cin>>size;
              cout<<"enter the element of array:-";

              for(i=0;i<size;i++)
              {
                cin>>arr[i];
              }
              cout<<"cube is:-";

              for(i=0;i<size;i++)
              {
                cout<<arr[i] * arr[i] * arr[i] << endl;
              }
}