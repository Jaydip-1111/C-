#include<iostream>
using namespace std;
int main(){
             int i=0;
             for(i=2000;i<=3000;i++)
             {
                if(i % 4 == 0)
                {
                    cout<<i<<"leap year"<<endl;
                }
             }
             return 0;
}