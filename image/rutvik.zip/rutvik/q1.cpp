#include<iostream>
using namespace std;

class X{
    public:
        int a,b,c;
        int A=0,B=0,C=0;
        int sum=0;
};

class Y : public X{
    public:
        void getData(){
            cout<<"Enter value of a : "<<endl;
            cin>>a;
            cout<<"Enter value of b : "<<endl;
            cin>>b;
            cout<<"Enter value of c : "<<endl;
            cin>>c;
        }
        void cube(){
            A=a*a*a;
            B=b*b*b;
            C=c*c*c;
            sum=A+B+C;
        }
        void printdata(){
            cout<<"cube of a is : "<<A<<endl;
            cout<<"cube of b is : "<<B<<endl;
            cout<<"cube of c is : "<<C<<endl;
            cout<<"Sum of all three cube is : "<<sum<<endl;
        }
};

int main(){
    Y y1;
    y1.getData();
    y1.cube();
    y1.printdata();
    return 0;
}