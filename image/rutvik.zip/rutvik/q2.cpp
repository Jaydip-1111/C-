#include<iostream>
using namespace std;

class P{
    public:
        float celsius,fahrenheit,kelvin;
};

class Q : public P{
    public:
        void toFahrenheit(){
            cout<<"Enter tempreture in celsius : ";
            cin>>celsius;
            fahrenheit = (celsius * 9.0) / 5.0 + 32;
            cout<<"The tempreture in degree fahrenheit : "<<fahrenheit<<endl;
        }
};

class R : public Q{
        public:
            void toKelvin(){
                kelvin = 273.5 + ((fahrenheit - 32.0) * (5.0/9.0));
                cout<<"The tempreture in kelvin : "<<kelvin<<endl;
            }
};

int main(){
    R r1;
    r1.toFahrenheit();
    r1.toKelvin();
    return 0;
}